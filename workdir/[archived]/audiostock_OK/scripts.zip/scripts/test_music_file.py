import os
import json
import argparse


def test_music_file(music_path, music_type=None):
    from mutagen.mp3 import MP3
    from mutagen.flac import FLAC
    
    audio_length = 0
    audio_info = {}
    
    def process_mp3_file(path):
        nonlocal audio_length
        nonlocal audio_info
        try:
            audio = MP3(path)
            audio_info[path] = audio.info.__dict__
            audio_length += audio.info.length
        except Exception as e:
            error_report = f'[{type(e).__name__}]: {e}'
            print(f'failed: {path}, {error_report}')
            
    def process_flac_file(path):
        nonlocal audio_length
        nonlocal audio_info
        try:
            audio = FLAC(path)
            audio_info[path] = audio.info.__dict__
            audio_length += audio.info.length
        except Exception as e:
            error_report = f'[{type(e).__name__}]: {e}'
            print(f'failed: {path}, {error_report}')
            
    if music_type is None:
        music_type = os.path.splitext(music_path)[1]
    
    all_supported_music_type = ['.mp3', '.flac']
    if music_type not in all_supported_music_type:
        raise ValueError(f'unsupported music type: {music_type}, supported: {all_supported_music_type}')
    process_audio_file = {
        '.mp3': process_mp3_file,
        '.flac': process_flac_file,
    }[music_type]
    process_audio_file(music_path)
    print(json.dumps(audio_info, indent=4, ensure_ascii=False))
    print(audio_length)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-i', '--music_path', type=str, help='path to the music file')
    parser.add_argument('-t', '--music_type', type=str, default=None, help='type of the music file')
    args = parser.parse_args()
    test_music_file(args.music_path, args.music_type)