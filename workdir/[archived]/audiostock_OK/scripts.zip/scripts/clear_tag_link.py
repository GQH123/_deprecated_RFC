import os
import json
import argparse


def clear_tag_link(jsonpath, savepath=None):
    data = json.load(open(jsonpath))
    jsonname = os.path.basename(jsonpath)
    if savepath is None:
        savepath = os.path.join('.', f'cleared_{jsonname}')
    cleared_data = {'tags': {}}
    for category in data['audio_tags']:
        cleared_data['tags'][category] = []
        for tag in data['audio_tags'][category]:
            cleared_data['tags'][category].append(tag[0])
    json.dump(cleared_data, open(savepath, 'w'), indent=4, ensure_ascii=False)


if __name__ == '__main__':
    argparser = argparse.ArgumentParser()
    argparser.add_argument('-i', '--jsonpath', type=str)
    argparser.add_argument('-o', '--savepath', type=str, default=None)  
    args = argparser.parse_args()
    clear_tag_link(args.jsonpath, args.savepath)