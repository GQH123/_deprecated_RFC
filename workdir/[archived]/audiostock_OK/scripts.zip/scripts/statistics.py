import os
import json
from tqdm import tqdm
import multiprocessing as mp

from mutagen.mp3 import MP3
from mutagen.flac import FLAC


def process_mp3_file(path):
    try:
        audio = MP3(path)
        return path, audio.info.__dict__, audio.info.length
    except Exception as e:
        error_report = f'[{type(e).__name__}]: {e}'
        print(f'failed: {path}, {error_report}', flush=True)
        return None


def process_flac_file(path):
    try:
        audio = FLAC(path)
        return path, audio.info.__dict__, audio.info.length
    except Exception as e:
        error_report = f'[{type(e).__name__}]: {e}'
        print(f'failed: {path}, {error_report}', flush=True)
        return None


process_audio_file = {
    '.mp3': process_mp3_file,
    '.flac': process_flac_file,
}


def _subprocess_statistics_music_length(dir):
    if os.path.exists(os.path.join('../saves/', dir, 'subs', dir, f'{dir}.mp3')):
        if not os.path.exists(os.path.join('../saves/', dir, f'{dir}.json')):
            print(f'warning: no json file found for {dir}', flush=True)
        return process_mp3_file(os.path.join('../saves/', dir, 'subs', dir, f'{dir}.mp3'))
    else:
        print(f'failed: no mp3 file found for {dir}', flush=True)


def statistics_music_length():
    audio_length = 0
    audio_info = {}
    
    if not os.path.exists('saves_dirs.txt'):
        assert os.system('ls ../saves > saves_dirs.txt') == 0
    with open('saves_dirs.txt') as f:
        dirs = [str(int(line)) for line in f.read().split('\n') if line]
        
    with mp.Pool(12) as pool:
        for result in tqdm(pool.imap_unordered(_subprocess_statistics_music_length, dirs), total=len(dirs)):
            if result is None:
                continue
            path, info, length = result
            audio_info[path] = info
            audio_length += length
    
    json.dump(audio_info, open(f'audio_info_mp3.json', 'w'), indent=4, ensure_ascii=False)
    print(f'total length: {audio_length} secs', flush=True, end='')
    
    
def process_audio_info_mp3_key():
    audio_info = json.load(open('../submits/audio_info_mp3.json'))
    # print(json.dumps(list(audio_info)[:100], indent=4, ensure_ascii=False))
    """
        ...
        "../saves/1000045/subs/1000045/1000045.mp3",
        "../saves/1000054/subs/1000054/1000054.mp3",
        "../saves/1000047/subs/1000047/1000047.mp3",
        "../saves/1000058/subs/1000058/1000058.mp3",
        "../saves/1000056/subs/1000056/1000056.mp3",
        ...
    """
    _audio_info = {}
    # for step, audio_info_key in tqdm(enumerate(audio_info)):
        # if step == 1000:
        #     break
    for audio_info_key in tqdm(audio_info):
        audio_id = audio_info_key.split('/')[2]
        if audio_info_key != f'../saves/{audio_id}/subs/{audio_id}/{audio_id}.mp3':
            print(f'warning: audio info key mismatch for {audio_id}, got {audio_info_key}', flush=True)
            continue
        _audio_info[audio_id] = audio_info[audio_info_key]
    json.dump(_audio_info, open('audio_info_mp3.json', 'w'), indent=4, ensure_ascii=False)


def statistics_music_category_length():
    audio_metas = json.load(open('../submits/audio_metas.json'))
    """
        {'title': '打ち込みバッキングトラックに即興のピア…', 'description': '打ち込みバッキングトラックに即興のピアノ重ねました。心理ゲームや映画のエンドロールにいかがでしょうか。', 'audio_id': 'No. 5', 'intro': 'GAME', 'length': '5:02', 'audio_type': 'BGM(インスト)', 'channel': 'ステレオ', 'data_info': ['MP3（192kbps）', 'INTEGRATED LOUDNESS (-9.0LUFS)'], 'release_date': '2013/11/06', 'tags': {'用途': ['オープニング(OP)', 'エンディング(ED)', 'ゲーム', '映画・シネマティック', 'アニメ', 'ドキュメンタリー・ドキュメント', 'ゲーム内音楽'], '楽器': ['ピアノ'], 'イメージ': ['疾走感', '緊張感', 'ミステリアス', '有名ゲーム風'], 'タグ': ['ドキュメンタリー', 'オープニング', 'エンディング', '映画', '緊迫感']}}
    """
    audio_info = json.load(open('../submits/audio_info_mp3.json'))
    """
        {'sketchy': False, 'length': 0.6502040816326531, 'frame_offset': 0, 'mode': 1, 'channels': 2, 'version': 1, 'layer': 3, 'protected': False, 'padding': False, 'bitrate': 127989, 'sample_rate': 44100, 'bitrate_mode': 1, 'encoder_settings': '-b 128', 'encoder_info': 'LAME 3.100.0+', 'track_gain': -9.2, 'track_peak': None, 'album_gain': None}
    """
    audio_type_info = {}
    for audio_id, audio_meta in tqdm(audio_metas.items()):
        # audio_info_key = f'../saves/{audio_id}/subs/{audio_id}/{audio_id}.mp3'
        audio_info_key = audio_id
        if audio_info_key not in audio_info:
            print(f'warning: no audio info found for {audio_id}', flush=True)
            continue
        audio_category = audio_meta['audio_type']
        audio_length = audio_info[audio_info_key]['length']
        if audio_category not in audio_type_info:
            audio_type_info[audio_category] = {
                'count': 0,
                'length': 0,
                'ids': [],
            }
        audio_type_info[audio_category]['count'] += 1
        audio_type_info[audio_category]['length'] += audio_length
        audio_type_info[audio_category]['ids'].append(audio_id)
    json.dump(audio_type_info, open(f'audio_types_details.json', 'w'), indent=4, ensure_ascii=False)
    for type in audio_type_info:
        del audio_type_info[type]['ids']
    json.dump(audio_type_info, open(f'audio_types.json', 'w'), indent=4, ensure_ascii=False)


# statistics_music_length()
# process_audio_info_mp3_key()
# statistics_music_category_length()