import os
import re
import json
import traceback
from tqdm import tqdm
import multiprocessing as mp

from RFC.utils.parse import (
    get_html_soup,
    parse,
)


savepath = '../saves/'


def parse_metainfo_from_html(htmlpath):
    with open(htmlpath, 'r') as f:
        html = f.read()
    _soup = get_html_soup(html)
    parse_config = {
        'title': {
            ('attr', 'h1', 'class', 'title-page-title mb-1', None): {
                ('result', 'text', None): {},
            },
        },
        'description': {
            ('attr', 'p', 'class', 'mb-0 break-word', None): {
                ('result', 'text', None): {},
            },
        },
        'info_part_1': {
            ('attr', 'ul', 'class', 'ul-reset mb-2', None): {
                ('type', 'li', None): {}
            },
        },
        'info_part_2': {
            ('attr', 'ul', 'class', 'ul-reset text-sm text-gray', None): {
                ('type', 'li', None): {}
            },
        },
    }
    result = {}
    for key in parse_config:
        if key.startswith('info'):
            info = []
            visited_li_soup = []
            for soup in parse(_soup, parse_config[key], return_str=False, debug=False):
                if soup in visited_li_soup:
                    continue
                if soup.ul is None:
                    info.append(soup.text.strip())
                    continue
                else:
                    text = soup.find(string=True).strip()
                    for li in soup.ul.find_all('li'):
                        visited_li_soup.append(li)
                        text += '\n'+li.text.strip()
                    info.append(text)
            result[key] = info
        else:
            result[key] = parse(_soup, parse_config[key], return_str=False, debug=False)[0]
    result['info'] = result.pop('info_part_1')+result.pop('info_part_2')
    info_dict = {}
    unknown_info_count = 0
    for info in result['info']:
        if ' : ' in info:
            key, value = info.split(' : ')
            info_dict[key] = value
        elif '\n：' in info:
            key, values = info.split('\n：')
            values = [value.strip() for value in values.split('\n') if value.strip()]
            info_dict[key] = values
        elif 'No. ' in info:
            key, value = 'audio_id', info
            info_dict[key] = value
        elif ':' in info:
            key, value = 'length', info
            info_dict[key] = value
        else:
            unknown_info_count += 1
            key, value = 'intro' if unknown_info_count == 1 else f'info_{unknown_info_count}', info
            info_dict[key] = value
    
    # for info in info_dict:
    #     if info == '音源種別':
    #         info_dict['audio_type'] = info_dict.pop(info)
    #     elif info == 'チャンネル':
    #         info_dict['channel'] = info_dict.pop(info)
    #     elif info == 'データ情報':
    #         info_dict['data_info'] = info_dict.pop(info)
    #     elif info == '公開日時':
    #         info_dict['release_date'] = info_dict.pop(info)
    if '音源種別' in info_dict:
        info_dict['audio_type'] = info_dict.pop('音源種別')
    if 'チャンネル' in info_dict:
        info_dict['channel'] = info_dict.pop('チャンネル')
    if 'データ情報' in info_dict:
        info_dict['data_info'] = info_dict.pop('データ情報')
    if '公開日時' in info_dict:
        info_dict['release_date'] = info_dict.pop('公開日時')

    result.pop('info')
    result = {**result, **info_dict}
    return result


def _subprocess_extract_audio_metas(dir):
    # print(dir, flush=True)
    if os.path.exists(os.path.join(savepath, dir, 'subs', dir, f'{dir}.mp3')):
        try:
            if not os.path.exists(os.path.join(savepath, dir, f'{dir}.json')):
                print(f'warning: no json file found for {dir}', flush=True)
                return None
            data = json.load(open(os.path.join(savepath, dir, f'{dir}.json')))
            meta = {'tags': {}}
            for category in data['audio_tags']:
                meta['tags'][category] = []
                for tag in data['audio_tags'][category]:
                    meta['tags'][category].append(tag[0])
            audio_id = re.findall('https://audiostock.jp/audio/([0-9]*).*', data['audio_link'])[0]
            # meta['id'] = audio_id
            if not os.path.exists(os.path.join(savepath, dir, f'{dir}.html')):
                print(f'warning: no html file found for {dir}', flush=True)
                return audio_id, meta
            meta = {**parse_metainfo_from_html(os.path.join(savepath, dir, f'{dir}.html')), **meta}
            # metas[audio_id] = meta
            return audio_id, meta
        except Exception as e:
            error_traceback = traceback.format_exc()
            error_report = f'[{type(e).__name__}] {str(e)}\n{error_traceback}'
            print(f'failed: ../saves/{dir}, {error_report}', flush=True)
    else:
        return None


def extract_audio_metas():
    if not os.path.exists('saves_dirs.txt'):
        assert os.system('ls ../saves > saves_dirs.txt') == 0
    with open('saves_dirs.txt') as f:
        dirs = [str(int(line)) for line in f.read().split('\n') if line]
    # dirs = [str(id) for id in range(1540000)]
    
    metas = {}
    with mp.Pool(24) as pool:
        for result in tqdm(pool.imap_unordered(_subprocess_extract_audio_metas, dirs), total=len(dirs)):
            if result is not None:
                audio_id, meta = result
                metas[audio_id] = meta
                # print(meta)
    metas = dict(sorted(metas.items(), key=lambda x: int(x[0])))
    json.dump(metas, open('audio_metas.json', 'w'), indent=4, ensure_ascii=False)


# print(json.dumps(parse_metainfo_from_html('../examples/1250993.html'), indent=4, ensure_ascii=False))
extract_audio_metas()