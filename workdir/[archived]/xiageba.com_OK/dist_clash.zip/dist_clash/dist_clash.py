import os
import json

"""
proxy_pool = (
    {
        'http': 'http://127.0.0.1:10000',
        'https': 'http://127.0.0.1:10000',
        'all': 'socks5://127.0.0.1:10000',
    },
    {
        'http': 'http://127.0.0.1:10002',
        'https': 'http://127.0.0.1:10002',
        'all': 'socks5://127.0.0.1:10002',
    },
    {
        'http': 'http://127.0.0.1:10004',
        'https': 'http://127.0.0.1:10004',
        'all': 'socks5://127.0.0.1:10004',
    },
)
"""


def launch(n_proxy, config_path, clash_st_port=20000):
    with open(config_path, 'r') as f:
        config = f.read()
    config_name = os.path.basename(config_path)
    launch_script = ''
    proxy_pool = []
    for i in range(n_proxy):
        port = clash_st_port + i * 2
        ui_port = port + 1
        dist_config = config.replace('mixed-port: 7890', f'mixed-port: {port}').replace('external-controller: 127.0.0.1:9090', f'external-controller: 127.0.0.1:{ui_port}').split('\n')
        assert dist_config[246] == '      - ♻️ 自动选择'
        dist_config[246] = dist_config[246].replace('♻️ 自动选择', f'IEPL-香港{i+1}')
        dist_config = '\n'.join(dist_config)
        dist_config_name = f'clash_dist_{i}.yaml'
        clash_log_name = f'clash_dist_{i}.log'
        with open(dist_config_name, 'w') as f:
            f.write(dist_config)
        launch_script += f'nohup ./clash-xiageba -d . -f {dist_config_name} 2>&1 > {clash_log_name} &\n'
        proxy_pool.append({
            'http': f'http://127.0.0.1:{port}',
            'https': f'http://127.0.0.1:{port}',
            'all': f'socks5://127.0.0.1:{port}',
        })
    with open('launch.sh', 'w') as f:
        f.write(launch_script)
    return proxy_pool


proxy_pool = launch(24, 'config.yaml')
print(f'proxy_pool = {json.dumps(proxy_pool, indent=4, ensure_ascii=False)}')